#proyecto libreria. 
construimos un sitio web para una libreria. empezamos por el front
